package com.project.farmingapp.model.data

data class Weather(val main:String =""
                   , val description:String =""
                   , val icon:String ="")