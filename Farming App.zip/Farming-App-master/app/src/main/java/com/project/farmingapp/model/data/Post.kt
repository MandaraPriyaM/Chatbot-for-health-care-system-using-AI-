package com.project.farmingapp.model.data

data class Post(val timeStamp: Long, val imageID: String, val imageUrl:String)