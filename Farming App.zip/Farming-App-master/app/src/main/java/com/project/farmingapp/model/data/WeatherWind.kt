package com.project.farmingapp.model.data

data class WeatherWind (val speed: Float)