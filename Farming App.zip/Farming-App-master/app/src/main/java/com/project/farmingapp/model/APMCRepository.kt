package com.project.farmingapp.model

class APMCRepository {
}